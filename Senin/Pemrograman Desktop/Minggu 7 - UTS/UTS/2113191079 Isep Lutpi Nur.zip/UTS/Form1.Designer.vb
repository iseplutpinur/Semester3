﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbMakanan = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbMakNasiRemes = New System.Windows.Forms.CheckBox()
        Me.cbMakNasiUduk = New System.Windows.Forms.CheckBox()
        Me.cbMakNasiRamen = New System.Windows.Forms.CheckBox()
        Me.cbMakNasiGoreng = New System.Windows.Forms.CheckBox()
        Me.gbMinuman = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cbMinEsCampur = New System.Windows.Forms.CheckBox()
        Me.cbMinEsJuice = New System.Windows.Forms.CheckBox()
        Me.cbMinAirMineral = New System.Windows.Forms.CheckBox()
        Me.cbMinTehManis = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.tbMakTotal = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.tbMinTotal = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.tbTotal = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.btnGtOk = New System.Windows.Forms.Button()
        Me.tbGtDisValue = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.rbGtDisTidak = New System.Windows.Forms.RadioButton()
        Me.rbGtDisYa = New System.Windows.Forms.RadioButton()
        Me.tbGtTotalAll = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.gbMakanan.SuspendLayout()
        Me.gbMinuman.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbMakanan
        '
        Me.gbMakanan.Controls.Add(Me.Label4)
        Me.gbMakanan.Controls.Add(Me.Label3)
        Me.gbMakanan.Controls.Add(Me.Label2)
        Me.gbMakanan.Controls.Add(Me.Label1)
        Me.gbMakanan.Controls.Add(Me.cbMakNasiRemes)
        Me.gbMakanan.Controls.Add(Me.cbMakNasiUduk)
        Me.gbMakanan.Controls.Add(Me.cbMakNasiRamen)
        Me.gbMakanan.Controls.Add(Me.cbMakNasiGoreng)
        Me.gbMakanan.Location = New System.Drawing.Point(12, 12)
        Me.gbMakanan.Name = "gbMakanan"
        Me.gbMakanan.Size = New System.Drawing.Size(223, 162)
        Me.gbMakanan.TabIndex = 8
        Me.gbMakanan.TabStop = False
        Me.gbMakanan.Text = "Makanan"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(147, 128)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Rp. 17.500"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(147, 91)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Rp. 10.000"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(147, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Rp. 15.000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(147, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Rp. 12.000"
        '
        'cbMakNasiRemes
        '
        Me.cbMakNasiRemes.AutoSize = True
        Me.cbMakNasiRemes.Location = New System.Drawing.Point(17, 58)
        Me.cbMakNasiRemes.Name = "cbMakNasiRemes"
        Me.cbMakNasiRemes.Size = New System.Drawing.Size(83, 17)
        Me.cbMakNasiRemes.TabIndex = 11
        Me.cbMakNasiRemes.Text = "Nasi Remes"
        Me.cbMakNasiRemes.UseVisualStyleBackColor = True
        '
        'cbMakNasiUduk
        '
        Me.cbMakNasiUduk.AutoSize = True
        Me.cbMakNasiUduk.Location = New System.Drawing.Point(17, 91)
        Me.cbMakNasiUduk.Name = "cbMakNasiUduk"
        Me.cbMakNasiUduk.Size = New System.Drawing.Size(76, 17)
        Me.cbMakNasiUduk.TabIndex = 10
        Me.cbMakNasiUduk.Text = "Nasi Uduk"
        Me.cbMakNasiUduk.UseVisualStyleBackColor = True
        '
        'cbMakNasiRamen
        '
        Me.cbMakNasiRamen.AutoSize = True
        Me.cbMakNasiRamen.Location = New System.Drawing.Point(17, 124)
        Me.cbMakNasiRamen.Name = "cbMakNasiRamen"
        Me.cbMakNasiRamen.Size = New System.Drawing.Size(84, 17)
        Me.cbMakNasiRamen.TabIndex = 9
        Me.cbMakNasiRamen.Text = "Nasi Ramen"
        Me.cbMakNasiRamen.UseVisualStyleBackColor = True
        '
        'cbMakNasiGoreng
        '
        Me.cbMakNasiGoreng.AutoSize = True
        Me.cbMakNasiGoreng.Location = New System.Drawing.Point(17, 25)
        Me.cbMakNasiGoreng.Name = "cbMakNasiGoreng"
        Me.cbMakNasiGoreng.Size = New System.Drawing.Size(88, 17)
        Me.cbMakNasiGoreng.TabIndex = 8
        Me.cbMakNasiGoreng.Text = "Nasi  Goreng"
        Me.cbMakNasiGoreng.UseVisualStyleBackColor = True
        '
        'gbMinuman
        '
        Me.gbMinuman.Controls.Add(Me.Label5)
        Me.gbMinuman.Controls.Add(Me.Label6)
        Me.gbMinuman.Controls.Add(Me.Label7)
        Me.gbMinuman.Controls.Add(Me.Label8)
        Me.gbMinuman.Controls.Add(Me.cbMinEsCampur)
        Me.gbMinuman.Controls.Add(Me.cbMinEsJuice)
        Me.gbMinuman.Controls.Add(Me.cbMinAirMineral)
        Me.gbMinuman.Controls.Add(Me.cbMinTehManis)
        Me.gbMinuman.Location = New System.Drawing.Point(241, 12)
        Me.gbMinuman.Name = "gbMinuman"
        Me.gbMinuman.Size = New System.Drawing.Size(223, 162)
        Me.gbMinuman.TabIndex = 16
        Me.gbMinuman.TabStop = False
        Me.gbMinuman.Text = "Minuman"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(147, 128)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Rp. 4.000"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(147, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Rp. 7.000"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(147, 58)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Rp.8 .000"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(147, 25)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Rp. 5.000"
        '
        'cbMinEsCampur
        '
        Me.cbMinEsCampur.AutoSize = True
        Me.cbMinEsCampur.Location = New System.Drawing.Point(17, 58)
        Me.cbMinEsCampur.Name = "cbMinEsCampur"
        Me.cbMinEsCampur.Size = New System.Drawing.Size(77, 17)
        Me.cbMinEsCampur.TabIndex = 11
        Me.cbMinEsCampur.Text = "Es Campur"
        Me.cbMinEsCampur.UseVisualStyleBackColor = True
        '
        'cbMinEsJuice
        '
        Me.cbMinEsJuice.AutoSize = True
        Me.cbMinEsJuice.Location = New System.Drawing.Point(17, 91)
        Me.cbMinEsJuice.Name = "cbMinEsJuice"
        Me.cbMinEsJuice.Size = New System.Drawing.Size(66, 17)
        Me.cbMinEsJuice.TabIndex = 10
        Me.cbMinEsJuice.Text = "Es Juice"
        Me.cbMinEsJuice.UseVisualStyleBackColor = True
        '
        'cbMinAirMineral
        '
        Me.cbMinAirMineral.AutoSize = True
        Me.cbMinAirMineral.Location = New System.Drawing.Point(17, 124)
        Me.cbMinAirMineral.Name = "cbMinAirMineral"
        Me.cbMinAirMineral.Size = New System.Drawing.Size(75, 17)
        Me.cbMinAirMineral.TabIndex = 9
        Me.cbMinAirMineral.Text = "Air Mineral"
        Me.cbMinAirMineral.UseVisualStyleBackColor = True
        '
        'cbMinTehManis
        '
        Me.cbMinTehManis.AutoSize = True
        Me.cbMinTehManis.Location = New System.Drawing.Point(17, 25)
        Me.cbMinTehManis.Name = "cbMinTehManis"
        Me.cbMinTehManis.Size = New System.Drawing.Size(76, 17)
        Me.cbMinTehManis.TabIndex = 8
        Me.cbMinTehManis.Text = "Teh Manis"
        Me.cbMinTehManis.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.tbMakTotal)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 180)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(223, 56)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Total Makanan"
        '
        'tbMakTotal
        '
        Me.tbMakTotal.Enabled = False
        Me.tbMakTotal.Location = New System.Drawing.Point(117, 23)
        Me.tbMakTotal.Name = "tbMakTotal"
        Me.tbMakTotal.Size = New System.Drawing.Size(100, 20)
        Me.tbMakTotal.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 23)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Total"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.tbMinTotal)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Location = New System.Drawing.Point(241, 180)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(223, 56)
        Me.GroupBox4.TabIndex = 17
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Total Minuman"
        '
        'tbMinTotal
        '
        Me.tbMinTotal.Enabled = False
        Me.tbMinTotal.Location = New System.Drawing.Point(117, 23)
        Me.tbMinTotal.Name = "tbMinTotal"
        Me.tbMinTotal.Size = New System.Drawing.Size(100, 20)
        Me.tbMinTotal.TabIndex = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 23)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Total"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.tbTotal)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 242)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(452, 56)
        Me.GroupBox5.TabIndex = 17
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Total"
        '
        'tbTotal
        '
        Me.tbTotal.Enabled = False
        Me.tbTotal.Location = New System.Drawing.Point(346, 27)
        Me.tbTotal.Name = "tbTotal"
        Me.tbTotal.Size = New System.Drawing.Size(100, 20)
        Me.tbTotal.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(181, 27)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(146, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Total Makanan dan Minuman"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.btnGtOk)
        Me.GroupBox6.Controls.Add(Me.tbGtDisValue)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.rbGtDisTidak)
        Me.GroupBox6.Controls.Add(Me.rbGtDisYa)
        Me.GroupBox6.Controls.Add(Me.tbGtTotalAll)
        Me.GroupBox6.Controls.Add(Me.Label12)
        Me.GroupBox6.Location = New System.Drawing.Point(12, 304)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(452, 56)
        Me.GroupBox6.TabIndex = 18
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Grand Total"
        '
        'btnGtOk
        '
        Me.btnGtOk.Location = New System.Drawing.Point(278, 21)
        Me.btnGtOk.Name = "btnGtOk"
        Me.btnGtOk.Size = New System.Drawing.Size(49, 23)
        Me.btnGtOk.TabIndex = 6
        Me.btnGtOk.Text = "OK"
        Me.btnGtOk.UseVisualStyleBackColor = True
        '
        'tbGtDisValue
        '
        Me.tbGtDisValue.Enabled = False
        Me.tbGtDisValue.Location = New System.Drawing.Point(184, 22)
        Me.tbGtDisValue.Name = "tbGtDisValue"
        Me.tbGtDisValue.Size = New System.Drawing.Size(62, 20)
        Me.tbGtDisValue.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(249, 26)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(15, 13)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "%"
        '
        'rbGtDisTidak
        '
        Me.rbGtDisTidak.AutoSize = True
        Me.rbGtDisTidak.Checked = True
        Me.rbGtDisTidak.Location = New System.Drawing.Point(110, 24)
        Me.rbGtDisTidak.Name = "rbGtDisTidak"
        Me.rbGtDisTidak.Size = New System.Drawing.Size(52, 17)
        Me.rbGtDisTidak.TabIndex = 3
        Me.rbGtDisTidak.TabStop = True
        Me.rbGtDisTidak.Text = "Tidak"
        Me.rbGtDisTidak.UseVisualStyleBackColor = True
        '
        'rbGtDisYa
        '
        Me.rbGtDisYa.AutoSize = True
        Me.rbGtDisYa.Location = New System.Drawing.Point(66, 24)
        Me.rbGtDisYa.Name = "rbGtDisYa"
        Me.rbGtDisYa.Size = New System.Drawing.Size(38, 17)
        Me.rbGtDisYa.TabIndex = 2
        Me.rbGtDisYa.TabStop = True
        Me.rbGtDisYa.Text = "Ya"
        Me.rbGtDisYa.UseVisualStyleBackColor = True
        '
        'tbGtTotalAll
        '
        Me.tbGtTotalAll.Enabled = False
        Me.tbGtTotalAll.Location = New System.Drawing.Point(346, 22)
        Me.tbGtTotalAll.Name = "tbGtTotalAll"
        Me.tbGtTotalAll.Size = New System.Drawing.Size(100, 20)
        Me.tbGtTotalAll.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(14, 26)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(49, 13)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Discount"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(475, 382)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.gbMinuman)
        Me.Controls.Add(Me.gbMakanan)
        Me.Name = "Form1"
        Me.Text = "UTS"
        Me.gbMakanan.ResumeLayout(False)
        Me.gbMakanan.PerformLayout()
        Me.gbMinuman.ResumeLayout(False)
        Me.gbMinuman.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gbMakanan As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbMakNasiRemes As System.Windows.Forms.CheckBox
    Friend WithEvents cbMakNasiUduk As System.Windows.Forms.CheckBox
    Friend WithEvents cbMakNasiRamen As System.Windows.Forms.CheckBox
    Friend WithEvents cbMakNasiGoreng As System.Windows.Forms.CheckBox
    Friend WithEvents gbMinuman As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cbMinEsCampur As System.Windows.Forms.CheckBox
    Friend WithEvents cbMinEsJuice As System.Windows.Forms.CheckBox
    Friend WithEvents cbMinAirMineral As System.Windows.Forms.CheckBox
    Friend WithEvents cbMinTehManis As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents tbMakTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents tbMinTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents tbTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnGtOk As System.Windows.Forms.Button
    Friend WithEvents tbGtDisValue As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents rbGtDisTidak As System.Windows.Forms.RadioButton
    Friend WithEvents rbGtDisYa As System.Windows.Forms.RadioButton
    Friend WithEvents tbGtTotalAll As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbNamaSuplier = New System.Windows.Forms.ComboBox()
        Me.rdoMeter = New System.Windows.Forms.RadioButton()
        Me.rdoLiter = New System.Windows.Forms.RadioButton()
        Me.rdoBox = New System.Windows.Forms.RadioButton()
        Me.rdoDus = New System.Windows.Forms.RadioButton()
        Me.rdoBotol = New System.Windows.Forms.RadioButton()
        Me.rdoPieces = New System.Windows.Forms.RadioButton()
        Me.txtNamaBarang = New System.Windows.Forms.TextBox()
        Me.txtHarga = New System.Windows.Forms.TextBox()
        Me.txtKodeBarang = New System.Windows.Forms.TextBox()
        Me.btnKeluar = New System.Windows.Forms.Button()
        Me.btnBatal = New System.Windows.Forms.Button()
        Me.btnSimpan = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 172)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Harga"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Suplier"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 102)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "Satuan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Nama Barang"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "Kode barang"
        '
        'cmbNamaSuplier
        '
        Me.cmbNamaSuplier.FormattingEnabled = True
        Me.cmbNamaSuplier.Location = New System.Drawing.Point(104, 66)
        Me.cmbNamaSuplier.Name = "cmbNamaSuplier"
        Me.cmbNamaSuplier.Size = New System.Drawing.Size(166, 21)
        Me.cmbNamaSuplier.TabIndex = 30
        '
        'rdoMeter
        '
        Me.rdoMeter.AutoSize = True
        Me.rdoMeter.Location = New System.Drawing.Point(221, 137)
        Me.rdoMeter.Name = "rdoMeter"
        Me.rdoMeter.Size = New System.Drawing.Size(52, 17)
        Me.rdoMeter.TabIndex = 29
        Me.rdoMeter.Text = "Meter"
        Me.rdoMeter.UseVisualStyleBackColor = True
        '
        'rdoLiter
        '
        Me.rdoLiter.AutoSize = True
        Me.rdoLiter.Location = New System.Drawing.Point(221, 100)
        Me.rdoLiter.Name = "rdoLiter"
        Me.rdoLiter.Size = New System.Drawing.Size(45, 17)
        Me.rdoLiter.TabIndex = 28
        Me.rdoLiter.Text = "Liter"
        Me.rdoLiter.UseVisualStyleBackColor = True
        '
        'rdoBox
        '
        Me.rdoBox.AutoSize = True
        Me.rdoBox.Location = New System.Drawing.Point(168, 137)
        Me.rdoBox.Name = "rdoBox"
        Me.rdoBox.Size = New System.Drawing.Size(43, 17)
        Me.rdoBox.TabIndex = 27
        Me.rdoBox.Text = "Box"
        Me.rdoBox.UseVisualStyleBackColor = True
        '
        'rdoDus
        '
        Me.rdoDus.AutoSize = True
        Me.rdoDus.Location = New System.Drawing.Point(168, 100)
        Me.rdoDus.Name = "rdoDus"
        Me.rdoDus.Size = New System.Drawing.Size(44, 17)
        Me.rdoDus.TabIndex = 26
        Me.rdoDus.Text = "Dus"
        Me.rdoDus.UseVisualStyleBackColor = True
        '
        'rdoBotol
        '
        Me.rdoBotol.AutoSize = True
        Me.rdoBotol.Location = New System.Drawing.Point(104, 137)
        Me.rdoBotol.Name = "rdoBotol"
        Me.rdoBotol.Size = New System.Drawing.Size(49, 17)
        Me.rdoBotol.TabIndex = 25
        Me.rdoBotol.Text = "Botol"
        Me.rdoBotol.UseVisualStyleBackColor = True
        '
        'rdoPieces
        '
        Me.rdoPieces.AutoSize = True
        Me.rdoPieces.Location = New System.Drawing.Point(104, 100)
        Me.rdoPieces.Name = "rdoPieces"
        Me.rdoPieces.Size = New System.Drawing.Size(57, 17)
        Me.rdoPieces.TabIndex = 24
        Me.rdoPieces.Text = "Pieces"
        Me.rdoPieces.UseVisualStyleBackColor = True
        '
        'txtNamaBarang
        '
        Me.txtNamaBarang.Location = New System.Drawing.Point(104, 40)
        Me.txtNamaBarang.Name = "txtNamaBarang"
        Me.txtNamaBarang.Size = New System.Drawing.Size(166, 20)
        Me.txtNamaBarang.TabIndex = 23
        '
        'txtHarga
        '
        Me.txtHarga.Location = New System.Drawing.Point(104, 169)
        Me.txtHarga.Name = "txtHarga"
        Me.txtHarga.Size = New System.Drawing.Size(174, 20)
        Me.txtHarga.TabIndex = 22
        '
        'txtKodeBarang
        '
        Me.txtKodeBarang.Location = New System.Drawing.Point(104, 14)
        Me.txtKodeBarang.Name = "txtKodeBarang"
        Me.txtKodeBarang.Size = New System.Drawing.Size(128, 20)
        Me.txtKodeBarang.TabIndex = 21
        '
        'btnKeluar
        '
        Me.btnKeluar.Location = New System.Drawing.Point(217, 209)
        Me.btnKeluar.Name = "btnKeluar"
        Me.btnKeluar.Size = New System.Drawing.Size(56, 40)
        Me.btnKeluar.TabIndex = 20
        Me.btnKeluar.Text = "Keluar"
        Me.btnKeluar.UseVisualStyleBackColor = True
        '
        'btnBatal
        '
        Me.btnBatal.Location = New System.Drawing.Point(159, 209)
        Me.btnBatal.Name = "btnBatal"
        Me.btnBatal.Size = New System.Drawing.Size(52, 40)
        Me.btnBatal.TabIndex = 19
        Me.btnBatal.Text = "Batal"
        Me.btnBatal.UseVisualStyleBackColor = True
        '
        'btnSimpan
        '
        Me.btnSimpan.Location = New System.Drawing.Point(98, 209)
        Me.btnSimpan.Name = "btnSimpan"
        Me.btnSimpan.Size = New System.Drawing.Size(55, 40)
        Me.btnSimpan.TabIndex = 18
        Me.btnSimpan.Text = "Simpan"
        Me.btnSimpan.UseVisualStyleBackColor = True
        '
        'frmInput
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbNamaSuplier)
        Me.Controls.Add(Me.rdoMeter)
        Me.Controls.Add(Me.rdoLiter)
        Me.Controls.Add(Me.rdoBox)
        Me.Controls.Add(Me.rdoDus)
        Me.Controls.Add(Me.rdoBotol)
        Me.Controls.Add(Me.rdoPieces)
        Me.Controls.Add(Me.txtNamaBarang)
        Me.Controls.Add(Me.txtHarga)
        Me.Controls.Add(Me.txtKodeBarang)
        Me.Controls.Add(Me.btnKeluar)
        Me.Controls.Add(Me.btnBatal)
        Me.Controls.Add(Me.btnSimpan)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmInput"
        Me.Text = "Identitas Barang"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbNamaSuplier As System.Windows.Forms.ComboBox
    Friend WithEvents rdoMeter As System.Windows.Forms.RadioButton
    Friend WithEvents rdoLiter As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBox As System.Windows.Forms.RadioButton
    Friend WithEvents rdoDus As System.Windows.Forms.RadioButton
    Friend WithEvents rdoBotol As System.Windows.Forms.RadioButton
    Friend WithEvents rdoPieces As System.Windows.Forms.RadioButton
    Friend WithEvents txtNamaBarang As System.Windows.Forms.TextBox
    Friend WithEvents txtHarga As System.Windows.Forms.TextBox
    Friend WithEvents txtKodeBarang As System.Windows.Forms.TextBox
    Friend WithEvents btnKeluar As System.Windows.Forms.Button
    Friend WithEvents btnBatal As System.Windows.Forms.Button
    Friend WithEvents btnSimpan As System.Windows.Forms.Button

End Class
